<div>
    <div class="flex h-full w-full flex-1 flex-col gap-4 rounded-xl">
        <livewire:dashborad-widget-overview />
    </div>
</div>