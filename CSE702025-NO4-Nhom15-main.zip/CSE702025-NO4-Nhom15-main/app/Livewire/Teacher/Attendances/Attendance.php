<?php

namespace App\Livewire\Teacher\Attendances;

use Livewire\Component;

class Attendance extends Component
{
    public function render()
    {
        return view('livewire.teacher.attendances.attendance');
    }
}
